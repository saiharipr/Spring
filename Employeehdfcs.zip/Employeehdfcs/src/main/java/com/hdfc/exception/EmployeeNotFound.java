package com.hdfc.exception;

public class EmployeeNotFound extends Exception {
	public EmployeeNotFound(String string) {
		// TODO Auto-generated constructor stub
	}

	
}
