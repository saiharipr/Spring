package com.hdfc.service;

import java.util.List;

import com.hdfc.entity.Employee;
import com.hdfc.exception.EmployeeNotFound;






public interface IEmployeeService {
	
	public Employee addEmployee(Employee employee);
	
	
	public Employee getEmployeeById(long employeeId) throws EmployeeNotFound;


	
	


}
